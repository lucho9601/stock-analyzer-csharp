﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStockAnalyzer
{
    /// <summary>
    /// Candlestick pattern analysis and detection
    /// </summary>
    public class SmartCandlesticks : CandlestickBuilder
    {
        public Boolean isBullish;
        public Boolean isBearish;
        public Boolean isNeutral;

        // Properties of our smart candlestick: range, body range, upper tail range, lower tail range
        public decimal range;
        public decimal bodyRange;
        public decimal upperTailRange;
        public decimal lowerTailRange;
        public decimal topOfBody;
        public decimal bottomOfBody;

        /// <summary>
        /// Default constructor
        /// </summary>
        public SmartCandlesticks() : base()
        {
            computeProperties();
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="SmartCandlesticks"/> class with the specified date, price data,
        /// and volume.
        /// </summary>
        /// <param name="date">The date and time associated with the candlestick.</param>
        /// <param name="open">The opening price of the candlestick.</param>
        /// <param name="high">The highest price of the candlestick.</param>
        /// <param name="low">The lowest price of the candlestick.</param>
        /// <param name="close">The closing price of the candlestick.</param>
        /// <param name="volume">The trading volume during the candlestick's time period.</param>
        // PARAMETERIZED CONSTRUCTOR
        public SmartCandlesticks(DateTime date, decimal open, decimal high, decimal low, decimal close, ulong volume) : base(date, open, high, low, close, volume)
        {
            computeProperties();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SmartCandlesticks"/> class by parsing a CSV line.
        /// </summary>
        /// <param name="csvLine"> Variable of type string that contains the content of our loaded csv file </param>
        // CSV LINE CONSTRUCTOR
        public SmartCandlesticks(String csvLine): base(csvLine)
        {
            // Calculate the ranges based on the candlestick properties
            computeProperties();
        }

        /// <summary>
        /// Copy constructor
        /// </summary>
        /// <param name="existingCandlestick"> An existing candlestick </param>
        // COPY CONSTRUCTOR
        public SmartCandlesticks(CandlestickBuilder existingCandlestick) : base(existingCandlestick)
        {
            computeProperties();
        }

        /// <summary>
        /// Copy constructor that is specific to SmartCandlesticks and is more efficient
        /// </summary>
        /// <param name="existingCandlestick"> An existing candlestick </param>
        // COPY CONSTRUCTOR FOR SMART CANDLESTICK
        public SmartCandlesticks(SmartCandlesticks scs) : base(scs)
        {
            // Directly copy the precomputed properties
            isBullish = scs.isBullish;
            isBearish = scs.isBearish;
            isNeutral = scs.isNeutral;
            range = scs.range;
            bodyRange = scs.bodyRange;
            upperTailRange = scs.upperTailRange;
            lowerTailRange = scs.lowerTailRange;
            topOfBody = scs.topOfBody;
            bottomOfBody = scs.bottomOfBody;

        }

        /// <summary>
        /// Function to compute the properties of the smart candlestick
        /// </summary>
        // CALCULATE PROPERTIES METHOD
        public void computeProperties()
        {
            // Determine if the candlestick is bullish, bearish, or neutral
            isBullish = close > open;
            isBearish = open > close;
            isNeutral = open == close;
            // Calculate the ranges based on the candlestick properties
            topOfBody = Math.Max(open, close);
            bottomOfBody = Math.Min(open, close);
            range = high - low;
            bodyRange = Math.Abs(close - open);
            upperTailRange = high - topOfBody;
            lowerTailRange = bottomOfBody - low;
        }
    }
}
