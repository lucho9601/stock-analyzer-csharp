﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStockAnalyzer
{
    /// <summary>
    /// Represents a recognizer for identifying the "Inverted Hammer" candlestick pattern in a list of candlesticks.
    /// </summary>
    public class Recognizer_InvertedHammer : Recognizer
    {
        // Inverted Hammer recognition logic
        public override Boolean recognize(List<SmartCandlesticks> ListofSmartCandles)
        {
            // If no candles, return false
            if (ListofSmartCandles.Count < 1)
                return false;
            // Get the most recent candle
            SmartCandlesticks candle = ListofSmartCandles[ListofSmartCandles.Count - 1];
            // Check for Inverted Hammer conditions
            if (candle.bodyRange <= (candle.range * 0.3m) && candle.upperTailRange >= (candle.bodyRange * 2) && candle.lowerTailRange <= candle.bodyRange)
            {
                patternIndices.Add(ListofSmartCandles.Count - 1);
                return true;
            }
            return false;
        }
        // Constructor that sets the pattern name and pattern size
        public Recognizer_InvertedHammer() : base("Inverted Hammer", 1) { }
    }

    /// <summary>
    /// Represents a recognizer for identifying the "Bearish Inverted Hammer" candlestick pattern in a list of candlesticks.
    /// </summary>
    public class Recognizer_BearishInvertedHammer : Recognizer
    {
        // Bearish Inverted Hammer recognition logic
        public override Boolean recognize(List<SmartCandlesticks> ListofSmartCandles)
        {
            // If no candles, return false
            if (ListofSmartCandles.Count < 1)
                return false;
            // Get the most recent candle
            SmartCandlesticks candle = ListofSmartCandles[ListofSmartCandles.Count - 1];
            // Check for Bearish Inverted Hammer conditions
            if (candle.bodyRange <= (candle.range * 0.3m) && candle.upperTailRange >= (candle.bodyRange * 2) && candle.lowerTailRange <= candle.bodyRange && candle.isBearish)
            {
                patternIndices.Add(ListofSmartCandles.Count - 1);
                return true;
            }
            return false;
        }
        // Constructor that sets the pattern name and pattern size
        public Recognizer_BearishInvertedHammer() : base("Bearish Inverted Hammer", 1) { }
    }

    /// <summary>
    /// Represents a recognizer for identifying the "Bullish Inverted Hammer" candlestick pattern in a list of candlesticks.
    /// </summary>
    public class Recognizer_BullishInvertedHammer : Recognizer
    {
        // Bullish Inverted Hammer recognition logic
        public override Boolean recognize(List<SmartCandlesticks> ListofSmartCandles)
        {
            // If no candles, return false
            if (ListofSmartCandles.Count < 1)
                return false;
            // Get the most recent candle
            SmartCandlesticks candle = ListofSmartCandles[ListofSmartCandles.Count - 1];
            // Check for Bullish Inverted Hammer conditions
            if (candle.bodyRange <= (candle.range * 0.3m) && candle.upperTailRange >= (candle.bodyRange * 2) && candle.lowerTailRange <= candle.bodyRange && candle.isBullish)
            {
                patternIndices.Add(ListofSmartCandles.Count - 1);
                return true;
            }
            return false;
        }
        // Constructor that sets the pattern name and pattern size
        public Recognizer_BullishInvertedHammer() : base("Bullish Inverted Hammer", 1) { }
    }
}
