﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStockAnalyzer
{
    /// <summary>
    /// Identifies the presence of a Harami candlestick pattern in a given dataset. Accepts both Bullish and Bearish Harami patterns.
    /// </summary>
    public class Recognizer_Harami : Recognizer
    {
        // General Harami pattern recognition logic
        public override Boolean recognize(List<SmartCandlesticks> ListofSmartCandles)
        {
            if (ListofSmartCandles.Count < 2)
                return false;

            SmartCandlesticks prevCandle = ListofSmartCandles[ListofSmartCandles.Count - 2];
            SmartCandlesticks currCandle = ListofSmartCandles[ListofSmartCandles.Count - 1];

            // Current body must be smaller than previous body (typical harami characteristic)
            if (currCandle.bodyRange >= prevCandle.bodyRange)
                return false;

            // Bullish Harami: previous bearish (large), current bullish (small), contained within
            if (prevCandle.isBearish && currCandle.isBullish && currCandle.bodyRange < prevCandle.bodyRange * 0.5m &&
                currCandle.open >= prevCandle.close && currCandle.close <= prevCandle.open)
            {
                patternIndices.Add(ListofSmartCandles.Count - 1);
                return true;
            }
            // Bearish Harami: previous bullish (large), current bearish (small), contained within
            else if (prevCandle.isBullish && currCandle.isBearish && currCandle.bodyRange < prevCandle.bodyRange * 0.5m &&
                currCandle.open <= prevCandle.close && currCandle.close >= prevCandle.open)
            {
                patternIndices.Add(ListofSmartCandles.Count - 1);
                return true;
            }
            return false;
        }
        // Constructor that sets the pattern name and pattern size
        public Recognizer_Harami() : base("Harami", 2) { }
    }

    /// <summary>
    /// Identifies the presence of a Bullish Harami candlestick pattern in a given dataset.
    /// </summary>
    public class Recognizer_BullishHarami : Recognizer
    {
        // Recognize method to identify Bullish Harami pattern
        public override Boolean recognize(List<SmartCandlesticks> ListofSmartCandles)
        {
            // Ensure there are at least two candles to compare
            if (ListofSmartCandles.Count < 2)
                return false;
            // Get the previous and current candles
            SmartCandlesticks prevCandle = ListofSmartCandles[ListofSmartCandles.Count - 2];
            SmartCandlesticks currCandle = ListofSmartCandles[ListofSmartCandles.Count - 1];
            // Bullish Harami: previous bearish (large), current bullish (small), contained within
            if (prevCandle.isBearish && currCandle.isBullish && currCandle.bodyRange < prevCandle.bodyRange * 0.5m &&
                currCandle.open >= prevCandle.close && currCandle.close <= prevCandle.open)
            {
                patternIndices.Add(ListofSmartCandles.Count - 1);
                return true;
            }

            return false;
        }
        // Constructor that sets the pattern name and pattern size
        public Recognizer_BullishHarami() : base("Bullish Harami", 2) { }
    }

    /// <summary>
    /// Identifies the presence of a Bearish Harami candlestick pattern in a given dataset.
    /// </summary>
    public class Recognizer_BearishHarami : Recognizer
    {
        // Recognize method to identify Bearish Harami pattern
        public override Boolean recognize(List<SmartCandlesticks> ListofSmartCandles)
        {
            if (ListofSmartCandles.Count < 2)
                return false;

            SmartCandlesticks prevCandle = ListofSmartCandles[ListofSmartCandles.Count - 2];
            SmartCandlesticks currCandle = ListofSmartCandles[ListofSmartCandles.Count - 1];

            // Previous must be large bullish, current must be small bearish            // Current body must be contained within previous body
            if (prevCandle.isBullish && currCandle.isBearish && currCandle.bodyRange < prevCandle.bodyRange * 0.5m &&                
                currCandle.open <= prevCandle.close && currCandle.close >= prevCandle.open)
            {
                patternIndices.Add(ListofSmartCandles.Count - 1);
                return true;
            }
            return false;
        }
        // Constructor that sets the pattern name and pattern size
        public Recognizer_BearishHarami() : base("Bearish Harami", 2) { }
    }
}
