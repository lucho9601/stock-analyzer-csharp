﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyStockAnalyzer
{
    public partial class Form_Home : Form
    {
        /// <summary>
        /// Form constructor for the home screen of the application
        /// </summary>
        public Form_Home()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Method to handle the button click event to open the file dialog
        /// </summary>
        /// <param name="sender"> The control that sent/triggered the event </param>
        /// <param name="e"> Event arguments containing our event data </param>
        private void button_LoadTicker_Click(object sender, EventArgs e)
        {
            openFileDialog_FileSelector.ShowDialog();
        }

        /// <summary>
        /// Method to handle the file selection event from the open file dialog 
        /// </summary>
        /// <param name="sender"> The control that sent/triggered the event </param>
        /// <param name="e"> Event arguments containing our event data </param>
        private void openFileDialog_FileSelector_FileOk(object sender, CancelEventArgs e)
        {
            // Get the selected start and end dates from the date pickers
            DateTime startDate = dateTimePicker_StartDate.Value;
            DateTime endDate = dateTimePicker_EndDate.Value;
            // Get all selected file paths from the file dialog and store them in a string array
            String[] filePaths = openFileDialog_FileSelector.FileNames;
            // For each selected file, create a new Form_Display instance
            foreach (string filePath in filePaths)
                new Form_Display(filePath, startDate, endDate);
        }
    }
}
