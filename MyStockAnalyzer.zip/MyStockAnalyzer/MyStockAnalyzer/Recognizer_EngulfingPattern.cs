﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStockAnalyzer
{
    /// <summary>
    /// Identifies the presence of an Engulfing candlestick pattern in a given dataset. Accepts both Bullish and Bearish Engulfing patterns.
    /// </summary>
    public class Recognizer_Engulfing : Recognizer
    {
        // Recognize method to identify Engulfing pattern
        public override Boolean recognize(List<SmartCandlesticks> ListofSmartCandles)
        {
            // If no candles, return false
            if (ListofSmartCandles.Count < 2)
                return false;
            // Get the previous and current candles
            SmartCandlesticks prevCandle = ListofSmartCandles[ListofSmartCandles.Count - 2];
            SmartCandlesticks currCandle = ListofSmartCandles[ListofSmartCandles.Count - 1];
            // Both candles should have significant bodies above a minimal threshold
            if (prevCandle.bodyRange < prevCandle.range * 0.1m || currCandle.bodyRange < currCandle.range * 0.1m)
                return false;
            // Current body should be meaningfully larger than previous
            if (currCandle.bodyRange < prevCandle.bodyRange * 1.2m)
                return false;
            // Bullish Engulfing: previous bearish, current bullish, current engulfs previous
            if (prevCandle.isBearish && currCandle.isBullish && currCandle.open <= prevCandle.close && currCandle.close >= prevCandle.open)
            {
                patternIndices.Add(ListofSmartCandles.Count - 1);
                return true;
            }
            // Bearish Engulfing: previous bullish, current bearish, current engulfs previous
            else if (prevCandle.isBullish && currCandle.isBearish && currCandle.open >= prevCandle.close && currCandle.close <= prevCandle.open)
            {
                patternIndices.Add(ListofSmartCandles.Count - 1);
                return true;
            }
            return false;
        }
        // Constructor that sets the pattern name and pattern size
        public Recognizer_Engulfing() : base("Engulfing", 2) { }
    }

    /// <summary>
    /// Identifies the presence of a Bullish Engulfing candlestick pattern in a given dataset.
    /// </summary>
    public class Recognizer_BullishEngulfing : Recognizer
    {
        // Recognize bullish engulfing pattern
        public override Boolean recognize(List<SmartCandlesticks> ListofSmartCandles)
        {
            // If no candles, return false
            if (ListofSmartCandles.Count < 2)
                return false;
            // Get the previous and current candles
            SmartCandlesticks prevCandle = ListofSmartCandles[ListofSmartCandles.Count - 2];
            SmartCandlesticks currCandle = ListofSmartCandles[ListofSmartCandles.Count - 1];
            // Both candles should have significant bodies above a minimal threshold
            if (prevCandle.bodyRange < prevCandle.range * 0.1m || currCandle.bodyRange < currCandle.range * 0.1m)
                return false;
            // Current body should be meaningfully larger than previous
            if (currCandle.bodyRange < prevCandle.bodyRange * 1.2m)
                return false;
            // Previous must be bearish, current must be bullish and current body must completely engulf previous body
            if (prevCandle.isBearish && currCandle.isBullish && currCandle.open <= prevCandle.close && currCandle.close >= prevCandle.open)
            {
                patternIndices.Add(ListofSmartCandles.Count - 1);
                return true;
            }

            return false;
        }
        // Constructor that sets the pattern name and pattern size
        public Recognizer_BullishEngulfing() : base("Bullish Engulfing", 2) { }
    }

    /// <summary>
    /// Identifies the presence of a Bearish Engulfing candlestick pattern in a given dataset.
    /// </summary>
    public class Recognizer_BearishEngulfing : Recognizer
    {
        // Recognize method to identify Bearish Engulfing pattern
        public override Boolean recognize(List<SmartCandlesticks> ListofSmartCandles)
        {
            // If no candles, return false
            if (ListofSmartCandles.Count < 2)
                return false;
            // Get the previous and current candles
            SmartCandlesticks prevCandle = ListofSmartCandles[ListofSmartCandles.Count - 2];
            SmartCandlesticks currCandle = ListofSmartCandles[ListofSmartCandles.Count - 1];
            // Both candles should have significant bodies above a minimal threshold
            if (prevCandle.bodyRange < prevCandle.range * 0.1m || currCandle.bodyRange < currCandle.range * 0.1m)
                return false;
            // Current body should be meaningfully larger than previous
            if (currCandle.bodyRange < prevCandle.bodyRange * 1.2m)
                return false;
            // Previous must be bullish, current must be bearish and current body must completely engulf previous body
            if (prevCandle.isBullish && currCandle.isBearish && currCandle.open >= prevCandle.close && currCandle.close <= prevCandle.open)
            {
                patternIndices.Add(ListofSmartCandles.Count - 1);
                return true;
            }
            return false;
        }
        // Constructor that sets the pattern name and pattern size
        public Recognizer_BearishEngulfing() : base("Bearish Engulfing", 2) { }
    }
}

