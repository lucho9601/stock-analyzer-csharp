﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStockAnalyzer
{
    /// <summary>
    /// Represents a recognizer for identifying the "Hammer" candlestick pattern in a list of candlesticks.
    /// </summary>
    public class Recognizer_Hammer : Recognizer
    {
        // General Hammer pattern recognition logic
        public override Boolean recognize(List<SmartCandlesticks> ListofSmartCandles)
        {
            // if no candles, return false
            if (ListofSmartCandles.Count < 1)
                return false;
            // Get the most recent candle
            SmartCandlesticks candle = ListofSmartCandles[ListofSmartCandles.Count - 1];
            // Hammer conditions
            if (candle.bodyRange <= (candle.range * 0.3m) && candle.lowerTailRange >= (candle.bodyRange * 2) && candle.upperTailRange <= candle.bodyRange)
            {
                patternIndices.Add(ListofSmartCandles.Count - 1);
                return true;
            }
            return false;
        }
        // Constructor that sets the pattern name and pattern size
        public Recognizer_Hammer() : base("Hammer", 1) { }
    }

    /// <summary>
    /// Represents a recognizer for identifying the "Bearish Hammer" candlestick pattern in a list of candlesticks.
    /// </summary>
    public class Recognizer_BearishHammer : Recognizer
    {
        // Bearish Hammer pattern recognition logic
        public override Boolean recognize(List<SmartCandlesticks> ListofSmartCandles)
        {
            // if no candles, return false 
            if (ListofSmartCandles.Count < 1)
                return false;
            // Get the most recent candle
            SmartCandlesticks candle = ListofSmartCandles[ListofSmartCandles.Count - 1];
            // Bearish Hammer conditions
            if (candle.bodyRange <= (candle.range * 0.3m) && candle.lowerTailRange >= (candle.bodyRange * 2) && candle.upperTailRange <= candle.bodyRange && candle.isBearish)
            {
                patternIndices.Add(ListofSmartCandles.Count - 1);
                return true;
            }

            return false;
        }
        // Constructor that sets the pattern name and pattern size
        public Recognizer_BearishHammer() : base("Bearish Hammer", 1) { }
    }

    /// <summary>
    /// Represents a recognizer for identifying the "Bullish Hammer" candlestick pattern in a list of candlesticks.
    /// </summary>
    public class Recognizer_BullishHammer : Recognizer
    {
        // Bullish Hammer pattern recognition logic
        public override Boolean recognize(List<SmartCandlesticks> ListofSmartCandles)
        {
            // if no candles, return false
            if (ListofSmartCandles.Count < 1)
                return false;
            // Get the most recent candle
            SmartCandlesticks candle = ListofSmartCandles[ListofSmartCandles.Count - 1];
            // Bullish Hammer conditions
            if (candle.bodyRange <= (candle.range * 0.3m) && candle.lowerTailRange >= (candle.bodyRange * 2) && candle.upperTailRange <= candle.bodyRange && candle.isBullish)
            {
                patternIndices.Add(ListofSmartCandles.Count - 1);
                return true;
            }
            return false;
        }
        // Constructor that sets the pattern name and pattern size
        public Recognizer_BullishHammer() : base("Bullish Hammer", 1) { }
    }
}
