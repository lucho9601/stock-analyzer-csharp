﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStockAnalyzer
{

    /// <summary>
    /// Base class for pattern recognizers that identify specific patterns in a list of SmartCandlesticks.
    /// </summary>
    public abstract class Recognizer
    {
        public int patternSize; //number of candles in pattern
        public string patternName; //name of pattern
        public List<int> patternIndices = new List<int>(); //list of starting indices where pattern is found

        //clear
        public void clear()
        {
            patternIndices.Clear();
        }
        //default constructor
        public Recognizer()
        {
            patternSize = 0;
            patternName = null;
        }
        // Parameterized constructor. It is the constructor that will be used as the base for all other recognizers
        public Recognizer(string PN, int PS)
        {
            this.patternSize = PS;
            this.patternName = PN;
        }
        // Abstract method to recognize patterns in a list of SmartCandlesticks
        public abstract Boolean recognize(List<SmartCandlesticks> ListofSmartCandles);
    }
}
