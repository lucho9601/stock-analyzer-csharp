﻿namespace MyStockAnalyzer
{
    partial class Form_Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dateTimePicker_StartDate = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker_EndDate = new System.Windows.Forms.DateTimePicker();
            this.button_LoadTicker = new System.Windows.Forms.Button();
            this.openFileDialog_FileSelector = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 26);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Start Date:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(708, 26);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "End Date:";
            // 
            // dateTimePicker_StartDate
            // 
            this.dateTimePicker_StartDate.Location = new System.Drawing.Point(145, 22);
            this.dateTimePicker_StartDate.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.dateTimePicker_StartDate.Name = "dateTimePicker_StartDate";
            this.dateTimePicker_StartDate.Size = new System.Drawing.Size(363, 29);
            this.dateTimePicker_StartDate.TabIndex = 0;
            this.dateTimePicker_StartDate.Value = new System.DateTime(2025, 1, 1, 0, 0, 0, 0);
            // 
            // dateTimePicker_EndDate
            // 
            this.dateTimePicker_EndDate.Location = new System.Drawing.Point(820, 22);
            this.dateTimePicker_EndDate.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.dateTimePicker_EndDate.Name = "dateTimePicker_EndDate";
            this.dateTimePicker_EndDate.Size = new System.Drawing.Size(363, 29);
            this.dateTimePicker_EndDate.TabIndex = 3;
            this.dateTimePicker_EndDate.Value = new System.DateTime(2025, 2, 28, 0, 0, 0, 0);
            // 
            // button_LoadTicker
            // 
            this.button_LoadTicker.Location = new System.Drawing.Point(522, 17);
            this.button_LoadTicker.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.button_LoadTicker.Name = "button_LoadTicker";
            this.button_LoadTicker.Size = new System.Drawing.Size(174, 42);
            this.button_LoadTicker.TabIndex = 0;
            this.button_LoadTicker.Text = "Load Tickers";
            this.button_LoadTicker.UseVisualStyleBackColor = true;
            this.button_LoadTicker.Click += new System.EventHandler(this.button_LoadTicker_Click);
            // 
            // openFileDialog_FileSelector
            // 
            this.openFileDialog_FileSelector.DefaultExt = "csv";
            this.openFileDialog_FileSelector.FileName = "ABBV-Day.csv ";
            this.openFileDialog_FileSelector.Filter = "\"All files\"|*.csv|\"Monthly Files\"|*-Month.csv|\"Weekly Files\"|*-Week.csv|\"Daily Fi" +
    "les\"|*-Day.csv";
            this.openFileDialog_FileSelector.FilterIndex = 4;
            this.openFileDialog_FileSelector.InitialDirectory = "C:\\Users\\lucho\\Documents\\USF Classes\\Fall 2025\\SSD\\Project 1\\Stock Data";
            this.openFileDialog_FileSelector.Multiselect = true;
            this.openFileDialog_FileSelector.ReadOnlyChecked = true;
            this.openFileDialog_FileSelector.ShowReadOnly = true;
            this.openFileDialog_FileSelector.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog_FileSelector_FileOk);
            // 
            // Form_Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1248, 90);
            this.Controls.Add(this.button_LoadTicker);
            this.Controls.Add(this.dateTimePicker_EndDate);
            this.Controls.Add(this.dateTimePicker_StartDate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "Form_Home";
            this.Text = "Form_Home";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTimePicker_StartDate;
        private System.Windows.Forms.DateTimePicker dateTimePicker_EndDate;
        private System.Windows.Forms.Button button_LoadTicker;
        private System.Windows.Forms.OpenFileDialog openFileDialog_FileSelector;
    }
}