﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace MyStockAnalyzer
{
    public partial class Form_Display : Form
    {
        // List to hold the ENTIRE candlestick data. This is the master list from which we will filter based on date range 
        List<SmartCandlesticks> listOfCandlesticks;
        // List to hold the filtered candlestick data based on the selected date range. This is the list we will use to update our display and is a subset of the master list
        List<SmartCandlesticks> filteredCandlesticks;
        // List to hold the simulated candlestick data (if any simulation is performed). We are initializing it with a capacity of 256 for efficiency.
        List<SmartCandlesticks> simulatedCandlesticks = new List<SmartCandlesticks>(256);
        // Collection of recognizers for different candlestick patterns
        List<Recognizer> listOfRecognizers = new List<Recognizer>();
        // Variable to hold the ticker file name for display purposes
        string tickerFile;

        /// <summary>
        /// Constructor for the StockAnalyzer form
        /// </summary>
        public Form_Display(string fileName, DateTime startDate, DateTime endDate)
        {
            InitializeComponent();
            // Initialize the recognizer collection
            Inititalize_Recognizer();
            // Initialize the pattern selection combo box
            Initialize_ComboBox();
            // Set the date pickers to the provided start and end dates
            dateTimePicker_StartDate.Value = startDate;
            dateTimePicker_EndDate.Value = endDate;
            //  Read the candlestick data from the provided file name
            listOfCandlesticks = readCandlestickFile(fileName);
            // Extract the ticker file name from the provided file path
            tickerFile = Path.GetFileNameWithoutExtension(fileName);
            // Set the file name in the open file dialog for reference
            openFileDialog_FileSelector.FileName = fileName;
            // Update the display with the read data
            updateDisplay();
            
        }
        /// <summary>
        /// Initializes the recognizer collection with a predefined set of candlestick pattern recognizers.
        /// </summary>
        // INITIALIZE RECOGNIZERS
        public void Inititalize_Recognizer() 
        {
            // Add all the recognizers that we have a class for to the list of recognizers
            listOfRecognizers.Add(new Recognizer_Doji());
            listOfRecognizers.Add(new Recognizer_DragonflyDoji());
            listOfRecognizers.Add(new Recognizer_GravestoneDoji());
            listOfRecognizers.Add(new Recognizer_Marubozu());
            listOfRecognizers.Add(new Recognizer_BearishMarubozu());
            listOfRecognizers.Add(new Recognizer_BullishMarubozu());
            listOfRecognizers.Add(new Recognizer_Hammer());
            listOfRecognizers.Add(new Recognizer_BearishHammer());
            listOfRecognizers.Add(new Recognizer_BullishHammer());
            listOfRecognizers.Add(new Recognizer_InvertedHammer());
            listOfRecognizers.Add(new Recognizer_BearishInvertedHammer());
            listOfRecognizers.Add(new Recognizer_BullishInvertedHammer());
            listOfRecognizers.Add(new Recognizer_Engulfing());
            listOfRecognizers.Add(new Recognizer_BullishEngulfing());
            listOfRecognizers.Add(new Recognizer_BearishEngulfing());
            listOfRecognizers.Add(new Recognizer_Harami());
            listOfRecognizers.Add(new Recognizer_BullishHarami());
            listOfRecognizers.Add(new Recognizer_BearishHarami());

        }
        /// <summary>
        /// Populates the combo box with pattern names from the list of recognizers.
        /// </summary>
        // INITIALIZE COMBO BOX
        public void Initialize_ComboBox()
        {
            // Clear existing items in the combo box
            comboBox_PatternName.Items.Clear();
            // Add each recognizer's pattern name to the combo box
            foreach (Recognizer r in listOfRecognizers)
            {
                
                comboBox_PatternName.Items.Add(r.patternName);
            }
        }
        /// <summary>
        /// Method to handle the button click event to open the file dialog
        /// </summary>
        /// <param name="sender"> The control that sent/triggered the event </param>
        /// <param name="e"> Event arguments containing our event data (in this case the click event of our refresh button) </param>
        // OPEN FILE DIALOG BUTTON CLICK EVENT HANDLER
        private void button_OpenFileDialog_Click(object sender, EventArgs e)
        {
            openFileDialog_FileSelector.ShowDialog();
        }

        /// <summary>
        ///  Method to handle the file selection event from the open file dialog
        /// </summary>
        /// <param name="sender"> The control that sent/triggered the event </param>
        /// <param name="e"> Event arguments containing our event data (in this case the click event of our refresh button) </param>
        // FILE SELECTOR OK EVENT HANDLER
        private void openFileDialog_FileSelector_FileOk(object sender, CancelEventArgs e)
        {
            // Display the selected file path as the form's title (for showing what file has been selected)
            Text = openFileDialog_FileSelector.FileName;
            // Read the candlestick data from the selected file
            listOfCandlesticks = readCandlestickFile(openFileDialog_FileSelector.FileName);
            // Update the display with the newly read data
            updateDisplay();
        }

        /// <summary>
        /// This function updates the display by filtering, normalizing, and updating the chart and data grid view.
        /// </summary>
        // UPDATE DISPLAY
        public void updateDisplay()
        {
            // Filter and sort the candlesticks based on the selected date range
            filterCandlesticks(listOfCandlesticks, dateTimePicker_StartDate.Value, dateTimePicker_EndDate.Value);
            // Set the data source for the chart to the filtered candlesticks
            chart_OHLCV.DataSource = filteredCandlesticks;
            // Normalize the chart based on the candlestick data
            normalizeChart(filteredCandlesticks);
            // Clear the existing titles and add new titles to the chart. Extremely important when implementing the refresh button to prevent duplicates from populating.
            chart_OHLCV.Titles.Clear();
            // The first title added is the ticker file name, and the second title indicates the date range being displayed.
            chart_OHLCV.Titles.Add(tickerFile);
            chart_OHLCV.Titles.Add("From " + dateTimePicker_StartDate.Value.ToString("d") + " to " + dateTimePicker_EndDate.Value.ToString("d"));
            // Show the form Form_Display
            this.Show();
        }

        /// <summary>
        /// Method to read the candlestick data from a CSV file
        /// </summary>
        /// <param name="tickerFile"> The string type variable that contains the path of the csv file from which we will extract our data </param>
        /// <returns></returns>
        // READ FILE
        public List<SmartCandlesticks> readCandlestickFile(string tickerFile)
        {
            // Initialize our list of candlestick to which we will add them as we read them from the file
            listOfCandlesticks = null;
            try
            {
                // We utilize a StreamReader to read the file line by line
                String fileContent;
                using (StreamReader reader = new StreamReader(tickerFile))
                {
                    // Read the entire file as a single string from beginning to end
                    fileContent = reader.ReadToEnd();
                }
                // Split the string into an array of strings, each representing a line in the file.
                // Although we do not need to specify new char[], it is good practice to do so in order to make the code more readable
                char[] delimeter = new char[] { '\n' };
                String[] lines = fileContent.Split(delimeter, StringSplitOptions.RemoveEmptyEntries);

                // Initialize the list of candlesticks
                listOfCandlesticks = new List<SmartCandlesticks>(lines.Length);

                // Iterate through each line in the file, skipping the first line which contains the headers
                for (int i = 1; i < lines.Length; i++)
                {
                    // Create a new CandlestickBuilder object from the line and add it to the list
                    listOfCandlesticks.Add(new SmartCandlesticks(lines[i]));
                }
            }
            // In case of any exceptions (like file not found, format issues, etc.), we catch them and display an error message
            catch (Exception ex)
            {
                MessageBox.Show("Error reading file: " + ex.Message);
                return null;
            }
            return listOfCandlesticks;
        }

        /// <summary>
        /// Method to filter and sort candlesticks within a specified date range
        /// </summary>
        /// <param name="candlesticks"> List of candlesticks we are using to apply our filters </param>
        /// <param name="startDate"> Start date we are using to filter our list by </param>
        /// <param name="endDate"> End date we are using to filter our list by </param>
        /// <returns></returns>
        // FILTER LIST
        private List<SmartCandlesticks> filterCandlesticks(List<SmartCandlesticks> candlesticks, DateTime startDate, DateTime endDate)
        {
            // Initialize a new list to hold the filtered candlesticks
            filteredCandlesticks = new List<SmartCandlesticks>();
            // Iterate through the original list of candlesticks
            foreach (SmartCandlesticks candlestick in candlesticks)
            {
                // If the candlestick's date is within the specified range, add it to the sorted list
                if (candlestick.date >= startDate && candlestick.date <= endDate)
                {
                    filteredCandlesticks.Add(candlestick);
                }
                // Since the list is assumed to be sorted by date, we can break the loop early if we exceed the end date
                if (candlestick.date >= endDate) break;
            }
            return filteredCandlesticks;
        }

        /// <summary>
        /// Method to produce a Normalized chart for better visualization of our candlestick data
        /// </summary>
        /// <param name="candlesticks"> List of candlestick that we are using to normalize our chart </param>
        // NORMALIZE CHART
        private void normalizeChart(List<SmartCandlesticks> candlesticks)
        {
            // Find the minimum and maximum values for the chart
            decimal minValue = candlesticks.Min(c => c.low);
            decimal maxValue = candlesticks.Max(c => c.high);
            // Add padding to the min and max prices for better visualization of 5% of the range
            decimal padding = (maxValue - minValue) * 0.05m;
            minValue -= padding;
            maxValue += padding;
            // Set the chart's Y-axis minimum and maximum values
            chart_OHLCV.ChartAreas["ChartArea_OHLC"].AxisY.Minimum = Math.Floor((double)minValue);
            chart_OHLCV.ChartAreas["ChartArea_OHLC"].AxisY.Maximum = Math.Floor((double)maxValue);
        }

        /// <summary>
        /// Method to handle the refresh button click event to update the display
        /// </summary>
        /// <param name="sender"> The control that sent/triggered the event </param>
        /// <param name="e"> Event arguments containing our event data (in this case the click event of our refresh button) </param>
        // REFRESH ON CLICK EVENT HANDLER
        private void button_Refresh_Click(object sender, EventArgs e)
        {
            // Clear all pattern indices
            chart_OHLCV.Annotations.Clear();
            // Clear all pattern indices from each recognizer
            foreach (Recognizer r in listOfRecognizers)
            {
                r.patternIndices.Clear();
            }
            // Call the update display method to refresh the data shown upon clicking the refresh button
            updateDisplay();
        }

        /// <summary>
        /// Event handler for the Simulate button click event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        // SIMULATE ON CLICK EVENT HANDLER
        private void button_Simulate_Click(object sender, EventArgs e)
        {
            // Clear all pattern indices
            foreach (Recognizer r in listOfRecognizers)
            {
                r.patternIndices.Clear();
            }
            // Disable the pattern selection combo box during simulation
            comboBox_PatternName.Enabled = false;
            // Clear any existing simulated candlesticks in order to prepare for new simulation data
            simulatedCandlesticks.Clear();
            // Change the DataSource of our chart to match the simulated candlesticks list
            chart_OHLCV.DataSource = simulatedCandlesticks;
            // Start the Timer to perform simulation steps at regular intervals
            timer_Simulate.Start();
        }

        /// <summary>
        /// Updates the chart to display the next candlestick in the simulation.
        /// </summary>
        // DISPLAY NEXT CANDLESTICK
        private void displayNextCandlestick()
        {
            // Re-normalize the chart to accommodate the newly added candlestick
            normalizeChart(simulatedCandlesticks);
            // Refresh the chart to reflect the newly added candlestick
            chart_OHLCV.DataBind();
        }

        /// <summary>
        /// Handles the tick event of the simulation timer, advancing the simulation by one candlestick.
        /// </summary>
        /// <param name="sender">The source of the event, typically the simulation timer.</param>
        /// <param name="e">The event data associated with the tick event.</param>
        // TIMER TICK EVENT HANDLER
        private void timer_Simulate_Tick(object sender, EventArgs e)
        {
            // Stop the timer to prevent overlapping ticks while processing
            timer_Simulate.Stop();
            // Adjust date time picker limits to prevent user interference during simulation
            dateTimePicker_StartDate.Enabled = false;
            dateTimePicker_EndDate.Enabled = false;
            // Add the next candlestick from the filtered list to the simulated list
            simulatedCandlesticks.Add(filteredCandlesticks[simulatedCandlesticks.Count]);
            // Update the chart to display the newly added candlestick
            displayNextCandlestick();
            // Run each recognizer on the updated simulated candlesticks
            foreach (Recognizer r in listOfRecognizers)
            {
                r.recognize(simulatedCandlesticks);
            }
            // Restart the timer if there are more candlesticks to simulate
            if (simulatedCandlesticks.Count < filteredCandlesticks.Count)
                timer_Simulate.Start();
            // If the simulation is complete, re-enable the pattern selection combo box and date pickers
            else
                comboBox_PatternName.Enabled = true;
                dateTimePicker_StartDate.Enabled = true;
                dateTimePicker_EndDate.Enabled = true;
        }

        /// <summary>
        /// Handles the <see cref="ScrollBar.Scroll"/> event for the simulation speed scrollbar.
        /// </summary>
        /// <param name="sender">The source of the event, typically the <see cref="HScrollBar"/> control.</param>
        /// <param name="e">A <see cref="ScrollEventArgs"/> that contains the event data.</param>
        // SCROLLBAR SCROLL EVENT HANDLER
        private void hScrollBar_SimulationSpeed_Scroll(object sender, ScrollEventArgs e)
        {
            // Update the timer interval based on the scrollbar value
            timer_Simulate.Interval = hScrollBar_SimulationSpeed.Value;
            // Update the text box to reflect the current simulation interval
            textBox_SimulationInterval.Text = hScrollBar_SimulationSpeed.Value.ToString();
            
        }

        /// <summary>
        /// Handles the <see cref="TextBox.TextChanged"/> event for the simulation interval text box.
        /// </summary>
        /// <param name="sender">The source of the event, typically the simulation interval text box.</param>
        /// <param name="e">An <see cref="EventArgs"/> instance containing the event data.</param>
        // TEXT BOX TEXT CHANGED EVENT HANDLER
        private void textBox_SimulationInterval_TextChanged(object sender, EventArgs e)
        {
            // Adjust the scrollbar value based on the text box input
            if (int.TryParse(textBox_SimulationInterval.Text, out int interval))
            {
                // Ensure the interval is within the scrollbar's range
                if (interval >= hScrollBar_SimulationSpeed.Minimum && interval <= hScrollBar_SimulationSpeed.Maximum)
                {
                    hScrollBar_SimulationSpeed.Value = interval;
                }
            }
            // Ensure the timer interval matches the value in the text box using data binding
            timer_Simulate.Interval = hScrollBar_SimulationSpeed.Value;
        }

        /// <summary>
        /// Handles the <see cref="ComboBox.SelectedIndexChanged"/> event for the pattern name selection. Updates the
        /// chart annotations based on the selected pattern.
        /// </summary>
        /// <param name="sender">The source of the event, typically the <see cref="ComboBox"/> control.</param>
        /// <param name="e">An <see cref="EventArgs"/> instance containing the event data.</param>
        // COMBO BOX SELECTED INDEX CHANGED EVENT HANDLER
        private void comboBox_PatternName_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedIndex = comboBox_PatternName.SelectedIndex;
            Recognizer selectedRecognizer = listOfRecognizers[selectedIndex];
            chart_OHLCV.Annotations.Clear();
            addAnnotation(selectedRecognizer);
            chart_OHLCV.Refresh();
        }

        /// <summary>
        /// Adds text annotations to the chart for the data points identified by the specified recognizer.
        /// </summary>
        /// <param name="r">The <see cref="Recognizer"/> containing the pattern indices and pattern name used to create the annotations.</param>
        // ADD ANNOTATION
        private void addAnnotation(Recognizer r)
        {
            // Get the list of pattern indices from the recognizer
            List<int> patternIndices = r.patternIndices;
            // Iterate through each index in the recognizer's pattern indices
            foreach (int index in patternIndices)
            {
                // Create a new text annotation for the chart
                DataPoint dp = chart_OHLCV.Series["Series_OHLC"].Points[index];
                // Create and configure the text annotation
                TextAnnotation annotation = new TextAnnotation
                {
                    Text = r.patternName,// Set the text to the pattern name
                    ForeColor = simulatedCandlesticks[index].close < simulatedCandlesticks[index].open ? Color.Red : Color.Green,
                    Font = new Font("Arial", 10, FontStyle.Bold), // Set the font style
                    AnchorDataPoint = dp, // Attach the annotation to the data point
                    Alignment = ContentAlignment.TopCenter,// Align the annotation to the top center of the data point
                };
                // Add the annotation to the chart's annotations collection
                chart_OHLCV.Annotations.Add(annotation);
            }
        }
    }
}
