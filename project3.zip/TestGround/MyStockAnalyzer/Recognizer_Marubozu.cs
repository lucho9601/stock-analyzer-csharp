﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStockAnalyzer
{
    /// <summary>
    /// Represents a recognizer for identifying the "Marubozu" candlestick pattern in a list of candlesticks.
    /// </summary>
    public class Recognizer_Marubozu : Recognizer
    {
        // Marubozu pattern recognition logic
        public override Boolean recognize(List<SmartCandlesticks> ListofSmartCandles)
        {
            // if no candles, return false
            if (ListofSmartCandles.Count < 1)
                return false;
            // Get the most recent candle
            SmartCandlesticks candle = ListofSmartCandles[ListofSmartCandles.Count - 1];
            // Check for Marubozu conditions
            if (candle.bodyRange >= (candle.range * 0.9m))
            {
                patternIndices.Add(ListofSmartCandles.Count - 1);
                return true;
            }
            return false;
        }
        // Constructor that sets the pattern name and pattern size
        public Recognizer_Marubozu() : base("Marubozu", 1) { }
    }

    /// <summary>
    /// Represents a recognizer for identifying the "Bearish Marubozu" candlestick pattern in a list of candlesticks.
    /// </summary>
    public class Recognizer_BearishMarubozu : Recognizer
    {
        // Bearish Marubozu pattern recognition logic
        public override Boolean recognize(List<SmartCandlesticks> ListofSmartCandles)
        {
            // if no candles, return false
            if (ListofSmartCandles.Count < 1)
                return false;
            // Get the most recent candle
            SmartCandlesticks candle = ListofSmartCandles[ListofSmartCandles.Count - 1];
            // Check for Bearish Marubozu conditions
            if (candle.bodyRange >= (candle.range * 0.9m) && candle.isBearish)
            {
                patternIndices.Add(ListofSmartCandles.Count - 1);
                return true;
            }
            return false;
        }
        // Constructor that sets the pattern name and pattern size
        public Recognizer_BearishMarubozu() : base("Bearish Marubozu", 1) { }
    }

    /// <summary>
    /// Represents a recognizer for identifying the "Bullish Marubozu" candlestick pattern in a list of candlesticks.
    /// </summary>
    public class Recognizer_BullishMarubozu : Recognizer
    {
        // Bullish Marubozu pattern recognition logic
        public override Boolean recognize(List<SmartCandlesticks> ListofSmartCandles)
        {
            // if no candles, return false
            if (ListofSmartCandles.Count < 1)
                return false;
            // Get the most recent candle
            SmartCandlesticks candle = ListofSmartCandles[ListofSmartCandles.Count - 1];
            // Check for Bullish Marubozu conditions
            if (candle.bodyRange >= (candle.range * 0.9m) && candle.isBullish)
            {
                patternIndices.Add(ListofSmartCandles.Count - 1);
                return true;
            }
            return false;
        }
        // Constructor that sets the pattern name and pattern size
        public Recognizer_BullishMarubozu() : base("Bullish Marubozu", 1) { }
    }
}
