﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStockAnalyzer
{
    public class CandlestickBuilder
    {
        // Properties of our candlestick: date, open, high, low, close, volume
        public DateTime date { get; set; }
        public decimal open { get; set; }
        public decimal high { get; set; }
        public decimal low { get; set; }
        public decimal close { get; set; }
        public ulong volume { get; set; }

        /// <summary>
        /// Default constructor
        /// </summary>
        public CandlestickBuilder() { }

        /// <summary>
        /// Constructor that would make a copy of another candlestick (not required, but useful as extra practice)
        /// </summary>
        /// <param name="existingCandlestick"> Candlestick we are using to perform the copy </param>
        public CandlestickBuilder(CandlestickBuilder existingCandlestick)
        {
            this.date = existingCandlestick.date;
            this.open = existingCandlestick.open;
            this.high = existingCandlestick.high;
            this.low = existingCandlestick.low;
            this.close = existingCandlestick.close;
            this.volume = existingCandlestick.volume;
        }

        // Delimeters that we will use to split the CSV file based on the actual content of the file (it would be different if other delimeters were used)
        private static char[] delimeters = { ',', '"' };

        /// <summary>
        /// Constructor that takes a string variable that contains the content of a CSV file, parses the string to extract the values needed to initializes the candlestick properties
        /// </summary>
        /// <param name="csvLine"> Variable of type string that contains the content of our loaded csv file </param>
        public CandlestickBuilder(String csvLine)
        {
            // Define the culture info for parsing (invariant culture is often used for CSV files)
            CultureInfo provider = CultureInfo.InvariantCulture;
            // Split the CSV line obtained from stream reader into parts based on the delimeters defined above
            String[] values = csvLine.Split(delimeters, StringSplitOptions.RemoveEmptyEntries);
            // Assign the values to the properties of the candlestick, converting them to the appropriate types
            date = DateTime.ParseExact(values[2], "yyyy-MM-dd", provider);
            open = decimal.Parse(values[3], provider);
            high = decimal.Parse(values[4], provider);
            low = decimal.Parse(values[5], provider);
            close = decimal.Parse(values[6], provider);
            volume = ulong.Parse(values[7], provider);
        }

        /// <summary>
        /// Constructor that initializes the candlestick properties with the provided values
        /// </summary>
        /// <param name="date">The date and time associated with the candlestick.</param>
        /// <param name="open">The opening price of the candlestick.</param>
        /// <param name="high">The highest price of the candlestick.</param>
        /// <param name="low">The lowest price of the candlestick.</param>
        /// <param name="close">The closing price of the candlestick.</param>
        /// <param name="volume">The trading volume during the candlestick's time period.</param>
        public CandlestickBuilder(DateTime date, decimal open, decimal high, decimal low, decimal close, ulong volume)
        {
            this.date = date;
            this.open = open;
            this.high = high;
            this.low = low;
            this.close = close;
            this.volume = volume;
        }
    }
}
