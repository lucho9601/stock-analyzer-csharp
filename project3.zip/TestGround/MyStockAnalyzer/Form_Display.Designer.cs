﻿namespace MyStockAnalyzer
{
    partial class Form_Display
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title2 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.button_openFileDialog = new System.Windows.Forms.Button();
            this.openFileDialog_FileSelector = new System.Windows.Forms.OpenFileDialog();
            this.dateTimePicker_StartDate = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker_EndDate = new System.Windows.Forms.DateTimePicker();
            this.StartDate = new System.Windows.Forms.Label();
            this.EndDate = new System.Windows.Forms.Label();
            this.chart_OHLCV = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.candlestickBuilderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button_Refresh = new System.Windows.Forms.Button();
            this.button_Simulate = new System.Windows.Forms.Button();
            this.timer_Simulate = new System.Windows.Forms.Timer(this.components);
            this.hScrollBar_SimulationSpeed = new System.Windows.Forms.HScrollBar();
            this.comboBox_PatternName = new System.Windows.Forms.ComboBox();
            this.textBox_SimulationInterval = new System.Windows.Forms.TextBox();
            this.ListOfPatterns = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.chart_OHLCV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.candlestickBuilderBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button_openFileDialog
            // 
            this.button_openFileDialog.Location = new System.Drawing.Point(15, 759);
            this.button_openFileDialog.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_openFileDialog.Name = "button_openFileDialog";
            this.button_openFileDialog.Size = new System.Drawing.Size(137, 27);
            this.button_openFileDialog.TabIndex = 0;
            this.button_openFileDialog.Text = "Load Ticker";
            this.button_openFileDialog.UseVisualStyleBackColor = true;
            this.button_openFileDialog.Click += new System.EventHandler(this.button_OpenFileDialog_Click);
            // 
            // openFileDialog_FileSelector
            // 
            this.openFileDialog_FileSelector.DefaultExt = "csv";
            this.openFileDialog_FileSelector.FileName = "ABBV-Day";
            this.openFileDialog_FileSelector.Filter = "\"All files\"|*.csv|\"Monthly Files\"|*-Month.csv|\"Weekly Files\"|*-Week.csv|\"Daily Fi" +
    "les\"|*-Day.csv";
            this.openFileDialog_FileSelector.InitialDirectory = "C:\\Users\\lucho\\Documents\\USF Classes\\Fall 2025\\SSD\\Project 1\\Stock Data";
            this.openFileDialog_FileSelector.Title = "Please select a single file to open.";
            this.openFileDialog_FileSelector.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog_FileSelector_FileOk);
            // 
            // dateTimePicker_StartDate
            // 
            this.dateTimePicker_StartDate.Location = new System.Drawing.Point(393, 762);
            this.dateTimePicker_StartDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateTimePicker_StartDate.Name = "dateTimePicker_StartDate";
            this.dateTimePicker_StartDate.Size = new System.Drawing.Size(251, 22);
            this.dateTimePicker_StartDate.TabIndex = 2;
            this.dateTimePicker_StartDate.Value = new System.DateTime(2025, 1, 1, 0, 0, 0, 0);
            // 
            // dateTimePicker_EndDate
            // 
            this.dateTimePicker_EndDate.Location = new System.Drawing.Point(751, 762);
            this.dateTimePicker_EndDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateTimePicker_EndDate.Name = "dateTimePicker_EndDate";
            this.dateTimePicker_EndDate.Size = new System.Drawing.Size(251, 22);
            this.dateTimePicker_EndDate.TabIndex = 3;
            this.dateTimePicker_EndDate.Value = new System.DateTime(2025, 2, 28, 0, 0, 0, 0);
            // 
            // StartDate
            // 
            this.StartDate.AutoSize = true;
            this.StartDate.Location = new System.Drawing.Point(312, 766);
            this.StartDate.Name = "StartDate";
            this.StartDate.Size = new System.Drawing.Size(69, 16);
            this.StartDate.TabIndex = 4;
            this.StartDate.Text = "Start Date:";
            // 
            // EndDate
            // 
            this.EndDate.AutoSize = true;
            this.EndDate.Location = new System.Drawing.Point(675, 766);
            this.EndDate.Name = "EndDate";
            this.EndDate.Size = new System.Drawing.Size(66, 16);
            this.EndDate.TabIndex = 5;
            this.EndDate.Text = "End Date:";
            // 
            // chart_OHLCV
            // 
            chartArea3.AxisX.Title = "Date";
            chartArea3.AxisY.Title = "OHLC";
            chartArea3.Name = "ChartArea_OHLC";
            chartArea4.AlignWithChartArea = "ChartArea_OHLC";
            chartArea4.AxisX.Title = "Date";
            chartArea4.AxisY.Title = "Volume";
            chartArea4.Name = "ChartArea_V";
            this.chart_OHLCV.ChartAreas.Add(chartArea3);
            this.chart_OHLCV.ChartAreas.Add(chartArea4);
            this.chart_OHLCV.DataSource = this.candlestickBuilderBindingSource;
            this.chart_OHLCV.Dock = System.Windows.Forms.DockStyle.Top;
            this.chart_OHLCV.Location = new System.Drawing.Point(0, 0);
            this.chart_OHLCV.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chart_OHLCV.Name = "chart_OHLCV";
            series3.BorderWidth = 3;
            series3.ChartArea = "ChartArea_OHLC";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Candlestick;
            series3.CustomProperties = "PriceDownColor=Red, PriceUpColor=Green";
            series3.IsXValueIndexed = true;
            series3.Name = "Series_OHLC";
            series3.XValueMember = "date";
            series3.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Date;
            series3.YValueMembers = "high, low, open, close";
            series3.YValuesPerPoint = 4;
            series4.ChartArea = "ChartArea_V";
            series4.IsXValueIndexed = true;
            series4.Name = "Series_V";
            series4.XValueMember = "date";
            series4.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Date;
            series4.YValueMembers = "volume";
            series4.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.UInt64;
            this.chart_OHLCV.Series.Add(series3);
            this.chart_OHLCV.Series.Add(series4);
            this.chart_OHLCV.Size = new System.Drawing.Size(1333, 720);
            this.chart_OHLCV.TabIndex = 2;
            this.chart_OHLCV.Text = "OHLCV Charts";
            title2.Name = "Title1";
            title2.Text = "The Title Goes Here!";
            this.chart_OHLCV.Titles.Add(title2);
            // 
            // button_Refresh
            // 
            this.button_Refresh.Location = new System.Drawing.Point(157, 759);
            this.button_Refresh.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_Refresh.Name = "button_Refresh";
            this.button_Refresh.Size = new System.Drawing.Size(140, 27);
            this.button_Refresh.TabIndex = 6;
            this.button_Refresh.Text = "Refresh Data View";
            this.button_Refresh.UseVisualStyleBackColor = true;
            this.button_Refresh.Click += new System.EventHandler(this.button_Refresh_Click);
            // 
            // button_Simulate
            // 
            this.button_Simulate.Location = new System.Drawing.Point(1027, 761);
            this.button_Simulate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_Simulate.Name = "button_Simulate";
            this.button_Simulate.Size = new System.Drawing.Size(140, 27);
            this.button_Simulate.TabIndex = 7;
            this.button_Simulate.Text = "Run Simulation";
            this.button_Simulate.UseVisualStyleBackColor = true;
            this.button_Simulate.Click += new System.EventHandler(this.button_Simulate_Click);
            // 
            // timer_Simulate
            // 
            this.timer_Simulate.Interval = 250;
            this.timer_Simulate.Tick += new System.EventHandler(this.timer_Simulate_Tick);
            // 
            // hScrollBar_SimulationSpeed
            // 
            this.hScrollBar_SimulationSpeed.Location = new System.Drawing.Point(15, 810);
            this.hScrollBar_SimulationSpeed.Maximum = 5000;
            this.hScrollBar_SimulationSpeed.Minimum = 100;
            this.hScrollBar_SimulationSpeed.Name = "hScrollBar_SimulationSpeed";
            this.hScrollBar_SimulationSpeed.Size = new System.Drawing.Size(283, 25);
            this.hScrollBar_SimulationSpeed.TabIndex = 8;
            this.hScrollBar_SimulationSpeed.Value = 1000;
            this.hScrollBar_SimulationSpeed.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar_SimulationSpeed_Scroll);
            // 
            // comboBox_PatternName
            // 
            this.comboBox_PatternName.FormattingEnabled = true;
            this.comboBox_PatternName.Location = new System.Drawing.Point(751, 811);
            this.comboBox_PatternName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox_PatternName.Name = "comboBox_PatternName";
            this.comboBox_PatternName.Size = new System.Drawing.Size(251, 24);
            this.comboBox_PatternName.TabIndex = 10;
            this.comboBox_PatternName.SelectedIndexChanged += new System.EventHandler(this.comboBox_PatternName_SelectedIndexChanged);
            // 
            // textBox_SimulationInterval
            // 
            this.textBox_SimulationInterval.Location = new System.Drawing.Point(316, 811);
            this.textBox_SimulationInterval.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_SimulationInterval.Name = "textBox_SimulationInterval";
            this.textBox_SimulationInterval.Size = new System.Drawing.Size(72, 22);
            this.textBox_SimulationInterval.TabIndex = 11;
            this.textBox_SimulationInterval.Text = "1000";
            this.textBox_SimulationInterval.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_SimulationInterval.TextChanged += new System.EventHandler(this.textBox_SimulationInterval_TextChanged);
            // 
            // ListOfPatterns
            // 
            this.ListOfPatterns.AutoSize = true;
            this.ListOfPatterns.Location = new System.Drawing.Point(639, 815);
            this.ListOfPatterns.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ListOfPatterns.Name = "ListOfPatterns";
            this.ListOfPatterns.Size = new System.Drawing.Size(98, 16);
            this.ListOfPatterns.TabIndex = 12;
            this.ListOfPatterns.Text = "List Of Patterns:";
            // 
            // Form_Display
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1333, 857);
            this.Controls.Add(this.ListOfPatterns);
            this.Controls.Add(this.textBox_SimulationInterval);
            this.Controls.Add(this.comboBox_PatternName);
            this.Controls.Add(this.hScrollBar_SimulationSpeed);
            this.Controls.Add(this.button_Simulate);
            this.Controls.Add(this.button_Refresh);
            this.Controls.Add(this.chart_OHLCV);
            this.Controls.Add(this.EndDate);
            this.Controls.Add(this.StartDate);
            this.Controls.Add(this.dateTimePicker_EndDate);
            this.Controls.Add(this.dateTimePicker_StartDate);
            this.Controls.Add(this.button_openFileDialog);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form_Display";
            this.Text = "StockAnalyzer";
            ((System.ComponentModel.ISupportInitialize)(this.chart_OHLCV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.candlestickBuilderBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_openFileDialog;
        private System.Windows.Forms.OpenFileDialog openFileDialog_FileSelector;
        private System.Windows.Forms.BindingSource candlestickBuilderBindingSource;
        private System.Windows.Forms.DateTimePicker dateTimePicker_StartDate;
        private System.Windows.Forms.DateTimePicker dateTimePicker_EndDate;
        private System.Windows.Forms.Label StartDate;
        private System.Windows.Forms.Label EndDate;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_OHLCV;
        private System.Windows.Forms.Button button_Refresh;
        private System.Windows.Forms.Button button_Simulate;
        private System.Windows.Forms.Timer timer_Simulate;
        private System.Windows.Forms.HScrollBar hScrollBar_SimulationSpeed;
        private System.Windows.Forms.ComboBox comboBox_PatternName;
        private System.Windows.Forms.TextBox textBox_SimulationInterval;
        private System.Windows.Forms.Label ListOfPatterns;
    }
}

