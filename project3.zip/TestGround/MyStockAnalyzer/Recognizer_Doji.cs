﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyStockAnalyzer
{
    /// <summary>
    /// Represents a recognizer for identifying the "Doji" candlestick pattern in a list of candlesticks.
    /// </summary>
    public class Recognizer_Doji : Recognizer
    {
        // Doji pattern recognition logic
        public override Boolean recognize(List<SmartCandlesticks> ListofSmartCandles)
        {
            // If no candles, return false
            if (ListofSmartCandles.Count < 1)
                return false;
            // Get the most recent candle
            SmartCandlesticks candle = ListofSmartCandles[ListofSmartCandles.Count - 1];
            // Check for Doji conditions
            if (candle.bodyRange <= (candle.range * 0.1m))
            {
                patternIndices.Add(ListofSmartCandles.Count - 1);
                return true;
            }
            return false;
        }
        // Constructor that sets the pattern name and pattern size
        public Recognizer_Doji() : base("Doji", 1) { }
    }

    /// <summary>
    /// Represents a recognizer for identifying the "Dragonfly Doji" candlestick pattern in a list of candlesticks.
    /// </summary>
    public class Recognizer_DragonflyDoji : Recognizer
    {
        // Dragonfly Doji pattern recognition logic
        public override Boolean recognize(List<SmartCandlesticks> ListofSmartCandles)
        {
            // If no candles, return false
            if (ListofSmartCandles.Count < 1)
                return false;
            // Get the most recent candle
            SmartCandlesticks candle = ListofSmartCandles[ListofSmartCandles.Count - 1];
            // Check for Dragonfly Doji conditions
            if (candle.bodyRange <= (candle.range * 0.1m) && candle.lowerTailRange >= (candle.range * 0.6m))
            {
                patternIndices.Add(ListofSmartCandles.Count - 1);
                return true;
            }
            return false;
        }
        // Constructor that sets the pattern name and pattern size
        public Recognizer_DragonflyDoji() : base("Dragonfly Doji", 1) { }
    }

    /// <summary>
    /// Represents a recognizer for identifying the "Gravestone Doji" candlestick pattern in a list of candlesticks.
    /// </summary>
    public class Recognizer_GravestoneDoji : Recognizer
    {
        // Gravestone Doji pattern recognition logic
        public override Boolean recognize(List<SmartCandlesticks> ListofSmartCandles)
        {
            // If no candles, return false
            if (ListofSmartCandles.Count < 1)
                return false;
            // Get the most recent candle
            SmartCandlesticks candle = ListofSmartCandles[ListofSmartCandles.Count - 1];
            // Check for Gravestone Doji conditions
            if (candle.bodyRange <= (candle.range * 0.1m) && candle.upperTailRange >= (candle.range * 0.6m))
            {
                patternIndices.Add(ListofSmartCandles.Count - 1);
                return true;
            }
            return false;
        }
        // Constructor that sets the pattern name and pattern size
        public Recognizer_GravestoneDoji() : base("Gravestone Doji", 1) { }
    }
}
